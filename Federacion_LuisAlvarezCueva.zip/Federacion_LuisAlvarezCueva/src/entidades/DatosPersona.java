package entidades;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import utils.Utilidades;
import validaciones.Validacion;

public class DatosPersona {
	private long id;
	private String nombre;
	private String telefono;
	private LocalDate fechaNac;

	private Documentacion nifnie;

	public DatosPersona(long id, String nombre, String telefono, LocalDate fechaNac) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.fechaNac = fechaNac;
	}

	public DatosPersona(long id, String nombre, String telefono, LocalDate fechaNac, Documentacion nifnie) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.fechaNac = fechaNac;
		this.nifnie = nifnie;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public LocalDate getFechaNac() {
		return fechaNac;
	}

	public void setFechaNac(LocalDate fechaNac) {
		this.fechaNac = fechaNac;
	}

	public Documentacion getNifnie() {
		return nifnie;
	}

	public void setNifnie(Documentacion nifnie) {
		this.nifnie = nifnie;
	}

	@Override
	public String toString() {
		return nombre + " NIF/NIE: " + nifnie.mostrar() + " Tfn:" + telefono + " ("
				+ fechaNac.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + ")";
	}

	public static DatosPersona nuevaPersona() {
		DatosPersona ret = null;
		Scanner in;
		long id = -1;
		String nombre = "";
		String tfn = "";
		boolean valido = false;
		do {
			System.out.println("Introduzca el id de la nueva persona:");
			in = new Scanner(System.in);
			id = in.nextInt();
			if (id > 0)
				valido = true;
		} while (!valido);
		valido = false;
		do {
			System.out.println("Introduzca el nombre de la nueva persona:");
			in = new Scanner(System.in);

			if (nombre.length() > 3 && Validacion.validarNombre(nombre = in.nextLine()))
				valido = true;
		} while (!valido);
		valido = false;
		do {
			System.out.println("Introduzca el telefono de la nueva persona:");
			in = new Scanner(System.in);
			tfn = in.nextLine();
			if (tfn.length() > 3 && Validacion.validarTelefono(tfn))
				valido = true;
		} while (!valido);
		valido = false;

		System.out.println("Introduzca la fecha de nacimiento de la nueva persona");
		LocalDate fecha = Utilidades.leerFecha();
		do {
			System.out.println("¿Va a introducir un NIF? (pulse 'S' par SÍ o 'N' para NIE)");
			boolean esnif = Utilidades.leerBoolean();
			Documentacion doc;
			if (esnif)
				do {
					doc = NIF.nuevoNIF();
					if (doc.validar())
						valido = true;
				} while (!valido);
			else
				do {
				doc = NIE.nuevoNIE();
				if (doc.validar())
					valido = true;
				}while(!valido);
			ret = new DatosPersona(id, nombre, tfn, fecha, doc);
		} while (!valido);
		return ret;
	}

}

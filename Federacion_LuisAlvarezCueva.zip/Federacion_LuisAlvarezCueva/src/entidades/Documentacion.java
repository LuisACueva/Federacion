package entidades;

public abstract class Documentacion {
	public abstract String mostrar();
	public abstract boolean validar();
}
